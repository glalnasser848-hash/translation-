# محرر الفيديو

## طريقة بناء الـ APK
1. أنشئ repository جديد على GitHub وارفع كل محتويات هذا المجلد (بما فيه مجلد .github).
2. افتح تبويب Actions ثم Build APK ثم Run workflow.
3. بعد 5-10 دقائق حمّل video-editor-apk من قسم Artifacts وثبّت ملف app-release.apk.

لو فشل البناء: انسخ رسالة الخطأ من الخطوة الحمراء.
