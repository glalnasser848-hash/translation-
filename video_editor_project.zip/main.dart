import 'dart:io';

import 'package:ffmpeg_kit_flutter_new/ffmpeg_kit.dart';
import 'package:ffmpeg_kit_flutter_new/return_code.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:video_player/video_player.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF121212),
        colorScheme: const ColorScheme.dark(primary: Color(0xFF7c3aed)),
      ),
      builder: (context, child) =>
          Directionality(textDirection: TextDirection.rtl, child: child!),
      home: const EditorScreen(),
    );
  }
}

// ---------------------------------------------------------------- models

class Clip {
  final double start;
  final double end;
  const Clip(this.start, this.end);
  double get length => end - start;
}

class Subtitle {
  String text;
  double start;
  double end;
  Subtitle(this.text, this.start, this.end);
}

enum Tool { trim, speed, compress, subtitles }

enum Quality {
  original('بدون ضغط', null, 18),
  light('خفيف 1080p', 1080, 23),
  medium('متوسط 720p', 720, 28),
  high('عالي 480p', 480, 32);

  final String label;
  final int? height;
  final int crf;
  const Quality(this.label, this.height, this.crf);
}

// ---------------------------------------------------------------- screen

class EditorScreen extends StatefulWidget {
  const EditorScreen({super.key});

  @override
  State<EditorScreen> createState() => _EditorScreenState();
}

class _EditorScreenState extends State<EditorScreen> {
  File? videoFile;
  VideoPlayerController? controller;

  RangeValues range = const RangeValues(0, 1);
  double total = 1;
  double speed = 1.0;
  bool muted = false;
  Quality quality = Quality.original;
  Tool tool = Tool.trim;

  final List<Clip> clips = [];
  final List<Subtitle> subtitles = [];

  bool exporting = false;
  String exportStatus = '';

  bool get ready => controller != null && controller!.value.isInitialized;

  double get position =>
      ready ? controller!.value.position.inMilliseconds / 1000.0 : 0;

  @override
  void dispose() {
    controller?.removeListener(_onTick);
    controller?.dispose();
    super.dispose();
  }

  // ------------------------------------------------------------ helpers

  void _snack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(msg)));
  }

  String _fmt(double s) {
    final d = Duration(milliseconds: (s * 1000).round());
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final sec = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    final h = d.inHours;
    return h > 0 ? '$h:$m:$sec' : '$m:$sec';
  }

  String _srtTime(double s) {
    final d = Duration(milliseconds: (s * 1000).round());
    String two(int n) => n.toString().padLeft(2, '0');
    final ms = d.inMilliseconds.remainder(1000).toString().padLeft(3, '0');
    return '${two(d.inHours)}:${two(d.inMinutes.remainder(60))}:'
        '${two(d.inSeconds.remainder(60))},$ms';
  }

  Future<void> _seek(double seconds) =>
      controller!.seekTo(Duration(milliseconds: (seconds * 1000).round()));

  // ------------------------------------------------------------ video

  Future<void> pickVideo() async {
    try {
      final result = await FilePicker.platform.pickFiles(type: FileType.video);
      final path = result?.files.single.path;
      if (path == null) return;

      final newController = VideoPlayerController.file(File(path));
      await newController.initialize();
      if (!mounted) {
        await newController.dispose();
        return;
      }

      final old = controller;
      old?.removeListener(_onTick);

      final secs = newController.value.duration.inMilliseconds / 1000.0;
      setState(() {
        videoFile = File(path);
        controller = newController;
        total = secs <= 0 ? 1 : secs;
        range = RangeValues(0, total);
        speed = 1.0;
        muted = false;
        clips.clear();
        subtitles.clear();
      });

      newController.addListener(_onTick);
      newController.play();
      WidgetsBinding.instance.addPostFrameCallback((_) => old?.dispose());
    } catch (e) {
      _snack('تعذر فتح الفيديو: $e');
    }
  }

  void _onTick() {
    final c = controller;
    if (c == null || !c.value.isInitialized || !mounted) return;
    // وقّف المعاينة عند نهاية المقطع المحدد
    if (c.value.isPlaying && position >= range.end) {
      c.pause();
      _seek(range.start);
    }
    setState(() {});
  }

  void _togglePlay() {
    if (!ready || exporting) return;
    final c = controller!;
    if (c.value.isPlaying) {
      c.pause();
    } else {
      if (position < range.start || position >= range.end - 0.05) {
        _seek(range.start);
      }
      c.play();
    }
  }

  // ------------------------------------------------------------ clips

  void saveClip() {
    if (!ready) return;
    if (range.end - range.start < 0.5) {
      _snack('المقطع قصير جدًا (أقل من نصف ثانية)');
      return;
    }
    setState(() => clips.add(Clip(range.start, range.end)));
    _snack('تم حفظ المقطع ${clips.length}');
  }

  // ------------------------------------------------------------ subtitles

  Subtitle? get activeSubtitle {
    final p = position;
    for (final s in subtitles) {
      if (p >= s.start && p <= s.end) return s;
    }
    return null;
  }

  Future<void> addSubtitle() async {
    if (!ready) return;
    final textController = TextEditingController();
    final text = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('إضافة ترجمة'),
        content: TextField(
          controller: textController,
          autofocus: true,
          maxLines: 3,
          decoration: const InputDecoration(hintText: 'اكتب النص هنا'),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
          TextButton(
              onPressed: () => Navigator.pop(ctx, textController.text.trim()),
              child: const Text('إضافة')),
        ],
      ),
    );
    textController.dispose();
    if (text == null || text.isEmpty) return;
    final s = position;
    final e = (s + 3).clamp(0, total).toDouble();
    setState(() {
      subtitles.add(Subtitle(text, s, e));
      subtitles.sort((a, b) => a.start.compareTo(b.start));
    });
  }

  Future<void> exportSrt() async {
    if (subtitles.isEmpty) {
      _snack('مفيش ترجمات لتصديرها');
      return;
    }
    try {
      // نحوّل التوقيتات لتطابق الفيديو الناتج (بعد القص وتغيير السرعة)
      final buf = StringBuffer();
      var n = 0;
      for (final s in subtitles) {
        final from = s.start < range.start ? range.start : s.start;
        final to = s.end > range.end ? range.end : s.end;
        if (to - from <= 0) continue;
        final outStart = (from - range.start) / speed;
        final outEnd = (to - range.start) / speed;
        n++;
        buf
          ..writeln(n)
          ..writeln('${_srtTime(outStart)} --> ${_srtTime(outEnd)}')
          ..writeln(s.text)
          ..writeln();
      }
      if (n == 0) {
        _snack('مفيش ترجمات داخل المقطع المحدد');
        return;
      }
      final dir = await getTemporaryDirectory();
      final file = File('${dir.path}/subtitles.srt');
      await file.writeAsString(buf.toString());
      await Share.shareXFiles([XFile(file.path)]);
    } catch (e) {
      _snack('فشل تصدير الترجمة: $e');
    }
  }

  // ------------------------------------------------------------ export

  List<String> _buildArgs(String input, Clip c, String out,
      {bool fallback = false}) {
    final vf = <String>[];
    final af = <String>[];

    if (speed != 1.0) {
      vf.add('setpts=PTS/$speed');
      af.add('atempo=$speed');
    }
    if (quality.height != null) {
      vf.add('scale=-2:min(${quality.height}\\,ih)');
    }

    // لو libx264 مش موجود في نسخة FFmpeg بنرجع لمشفّر mpeg4 المدمج
    final videoCodec = fallback
        ? ['-c:v', 'mpeg4', '-q:v', '${(quality.crf / 4).round().clamp(2, 12).toInt()}']
        : ['-c:v', 'libx264', '-preset', 'veryfast', '-crf', '${quality.crf}'];

    return [
      '-y',
      '-ss', c.start.toStringAsFixed(3),
      // -t قبل -i عشان يحدد مدة المقطع الأصلي (مش مدة الناتج بعد تغيير السرعة)
      '-t', c.length.toStringAsFixed(3),
      '-i', input,
      if (vf.isNotEmpty) ...['-vf', vf.join(',')],
      ...videoCodec,
      if (muted) '-an' else ...[
        if (af.isNotEmpty) ...['-af', af.join(',')],
        '-c:a', 'aac',
        '-b:a', '128k',
      ],
      '-movflags', '+faststart',
      out,
    ];
  }

  Future<bool> _runFfmpeg(List<String> args) async {
    final session = await FFmpegKit.executeWithArguments(args);
    final code = await session.getReturnCode();
    return ReturnCode.isSuccess(code);
  }

  // مسح الملفات المؤقتة الناتجة من التصدير
  Future<void> _cleanTemp(Directory dir) async {
    try {
      await for (final f in dir.list()) {
        if (f is File && f.uri.pathSegments.last.startsWith('edited_')) {
          await f.delete();
        }
      }
    } catch (_) {}
  }

  Future<void> exportVideo() async {
    if (!ready || videoFile == null) return;
    if (exporting) return;

    final jobs = clips.isNotEmpty
        ? List<Clip>.from(clips)
        : [Clip(range.start, range.end)];

    if (jobs.any((c) => c.length < 0.5)) {
      _snack('فيه مقطع أقصر من نصف ثانية');
      return;
    }

    controller!.pause();
    setState(() {
      exporting = true;
      exportStatus = '';
    });

    final outputs = <XFile>[];
    Directory? dir;
    try {
      dir = await getTemporaryDirectory();
      await _cleanTemp(dir);
      final stamp = DateTime.now().millisecondsSinceEpoch;

      for (var i = 0; i < jobs.length; i++) {
        if (!mounted) return;
        setState(() => exportStatus = 'جاري تصدير ${i + 1} من ${jobs.length}...');

        final out = '${dir.path}/edited_${stamp}_${i + 1}.mp4';
        var ok = await _runFfmpeg(_buildArgs(videoFile!.path, jobs[i], out));
        if (!ok) {
          // محاولة ثانية بمشفّر بديل
          ok = await _runFfmpeg(
              _buildArgs(videoFile!.path, jobs[i], out, fallback: true));
        }
        if (!ok) throw Exception('فشل تصدير المقطع ${i + 1}');
        outputs.add(XFile(out));
      }

      if (!mounted) return;
      _snack('تم التصدير بنجاح ✅');
      final box = context.findRenderObject() as RenderBox?;
      final origin = box == null ? null : box.localToGlobal(Offset.zero) & box.size;
      await Share.shareXFiles(outputs, sharePositionOrigin: origin);
    } catch (e) {
      _snack('$e');
    } finally {
      if (dir != null) await _cleanTemp(dir);
      if (mounted) setState(() => exporting = false);
    }
  }

  // ------------------------------------------------------------ UI

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('محرر الفيديو القوي 📁'),
        backgroundColor: const Color(0xFF2d1b69),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _bigButton('📁 رفع فيديو من الجهاز', const Color(0xFF7c3aed),
                  exporting ? null : pickVideo),
              const SizedBox(height: 12),
              _videoArea(),
              if (ready) ...[
                const SizedBox(height: 8),
                _playerControls(),
                const SizedBox(height: 8),
                _toolBar(),
                const SizedBox(height: 8),
                _toolPanel(),
                if (clips.isNotEmpty) ...[
                  const SizedBox(height: 12),
                  _clipsList(),
                ],
                const SizedBox(height: 16),
                if (exporting) ...[
                  const LinearProgressIndicator(),
                  const SizedBox(height: 6),
                  Text(exportStatus, textAlign: TextAlign.center),
                  const SizedBox(height: 10),
                ],
                _bigButton('💾 حفظ المقطع', Colors.orange,
                    exporting ? null : saveClip),
                const SizedBox(height: 8),
                _bigButton(
                    clips.isEmpty
                        ? '🎬 تصدير الفيديو'
                        : '🎬 تصدير ${clips.length} مقطع',
                    Colors.pinkAccent,
                    exporting ? null : exportVideo),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _bigButton(String text, Color color, VoidCallback? onPressed) {
    return SizedBox(
      height: 56,
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: color,
          foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        ),
        onPressed: onPressed,
        child: Text(text, style: const TextStyle(fontSize: 18)),
      ),
    );
  }

  Widget _videoArea() {
    if (!ready) {
      return Container(
        height: 200,
        decoration: BoxDecoration(
            color: Colors.black, borderRadius: BorderRadius.circular(12)),
        child: const Center(
            child: Text('اختر فيديو أولاً', style: TextStyle(color: Colors.grey))),
      );
    }
    final c = controller!;
    final sub = activeSubtitle;
    final maxH = MediaQuery.of(context).size.height * 0.4;
    return ConstrainedBox(
      constraints: BoxConstraints(maxHeight: maxH),
      child: Center(
        child: AspectRatio(
          aspectRatio: c.value.aspectRatio == 0 ? 16 / 9 : c.value.aspectRatio,
          child: GestureDetector(
            onTap: _togglePlay,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Stack(alignment: Alignment.center, children: [
                VideoPlayer(c),
                if (!c.value.isPlaying)
                  const Icon(Icons.play_circle_fill,
                      size: 64, color: Colors.white70),
                if (sub != null)
                  Positioned(
                    bottom: 16,
                    left: 8,
                    right: 8,
                    child: Center(
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 4),
                        color: Colors.black54,
                        child: Text(sub.text,
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                                color: Colors.white, fontSize: 20)),
                      ),
                    ),
                  ),
              ]),
            ),
          ),
        ),
      ),
    );
  }

  Widget _playerControls() {
    final c = controller!;
    final pos = position.clamp(0.0, total).toDouble();
    return Row(children: [
      IconButton(
        icon: Icon(c.value.isPlaying ? Icons.pause : Icons.play_arrow),
        onPressed: _togglePlay,
      ),
      Text(_fmt(pos), style: const TextStyle(fontSize: 12)),
      Expanded(
        child: Slider(
          value: pos,
          min: 0,
          max: total,
          onChanged: exporting ? null : (v) => _seek(v),
        ),
      ),
      Text(_fmt(total), style: const TextStyle(fontSize: 12)),
    ]);
  }

  Widget _toolBar() {
    Widget btn(Tool t, String label) => Expanded(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 3),
            child: InkWell(
              borderRadius: BorderRadius.circular(12),
              onTap: () => setState(() => tool = t),
              child: Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: tool == t ? Colors.orange : const Color(0xFF3a3a5c),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Center(
                    child: Text(label, textAlign: TextAlign.center)),
              ),
            ),
          ),
        );
    return Row(children: [
      btn(Tool.trim, '✂️ تقطيع'),
      btn(Tool.speed, '⚡ سرعة\nوصوت'),
      btn(Tool.compress, '🗜️ ضغط'),
      btn(Tool.subtitles, '💬 ترجمة'),
    ]);
  }

  Widget _toolPanel() {
    switch (tool) {
      case Tool.trim:
        return _trimPanel();
      case Tool.speed:
        return _speedPanel();
      case Tool.compress:
        return _compressPanel();
      case Tool.subtitles:
        return _subtitlePanel();
    }
  }

  Widget _panel(List<Widget> children) => Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
            color: const Color(0xFF1e1e2e),
            borderRadius: BorderRadius.circular(12)),
        child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch, children: children),
      );

  Widget _trimPanel() {
    return _panel([
      RangeSlider(
        values: range,
        min: 0,
        max: total,
        labels: RangeLabels(_fmt(range.start), _fmt(range.end)),
        onChanged: exporting
            ? null
            : (v) {
                final startMoved = v.start != range.start;
                setState(() => range = v);
                _seek(startMoved ? v.start : v.end);
              },
      ),
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Text('البداية: ${_fmt(range.start)}'),
        Text('المدة: ${_fmt(range.end - range.start)}'),
        Text('النهاية: ${_fmt(range.end)}'),
      ]),
      const SizedBox(height: 8),
      Row(children: [
        Expanded(
          child: OutlinedButton(
            onPressed: () {
              final p = position;
              if (p < range.end - 0.5) {
                setState(() => range = RangeValues(p, range.end));
              }
            },
            child: const Text('البداية هنا'),
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: OutlinedButton(
            onPressed: () {
              final p = position;
              if (p > range.start + 0.5) {
                setState(() => range = RangeValues(range.start, p));
              }
            },
            child: const Text('النهاية هنا'),
          ),
        ),
      ]),
    ]);
  }

  Widget _speedPanel() {
    const speeds = [0.5, 0.75, 1.0, 1.25, 1.5, 2.0];
    return _panel([
      const Text('سرعة الفيديو'),
      Wrap(
        spacing: 8,
        children: [
          for (final s in speeds)
            ChoiceChip(
              label: Text('${s}x'),
              selected: speed == s,
              onSelected: (_) {
                setState(() => speed = s);
                controller!.setPlaybackSpeed(s);
              },
            ),
        ],
      ),
      SwitchListTile(
        contentPadding: EdgeInsets.zero,
        title: const Text('كتم الصوت'),
        value: muted,
        onChanged: (v) {
          setState(() => muted = v);
          controller!.setVolume(v ? 0 : 1);
        },
      ),
    ]);
  }

  Widget _compressPanel() {
    return _panel([
      const Text('جودة التصدير'),
      Wrap(
        spacing: 8,
        children: [
          for (final q in Quality.values)
            ChoiceChip(
              label: Text(q.label),
              selected: quality == q,
              onSelected: (_) => setState(() => quality = q),
            ),
        ],
      ),
      const SizedBox(height: 6),
      const Text('كل ما الضغط زاد، الحجم قل والجودة نقصت.',
          style: TextStyle(color: Colors.grey, fontSize: 12)),
    ]);
  }

  Widget _subtitlePanel() {
    return _panel([
      Row(children: [
        Expanded(
          child: ElevatedButton.icon(
            onPressed: addSubtitle,
            icon: const Icon(Icons.add),
            label: const Text('إضافة عند الموضع الحالي'),
          ),
        ),
        const SizedBox(width: 8),
        IconButton(
            tooltip: 'تصدير SRT',
            onPressed: exportSrt,
            icon: const Icon(Icons.ios_share)),
      ]),
      if (subtitles.isEmpty)
        const Padding(
          padding: EdgeInsets.only(top: 8),
          child: Text('مفيش ترجمات لسه',
              style: TextStyle(color: Colors.grey)),
        ),
      for (var i = 0; i < subtitles.length; i++)
        ListTile(
          dense: true,
          contentPadding: EdgeInsets.zero,
          title: Text(subtitles[i].text,
              maxLines: 1, overflow: TextOverflow.ellipsis),
          subtitle: Text(
              '${_fmt(subtitles[i].start)} → ${_fmt(subtitles[i].end)}'),
          onTap: () => _seek(subtitles[i].start),
          trailing: IconButton(
            icon: const Icon(Icons.delete_outline),
            onPressed: () => setState(() => subtitles.removeAt(i)),
          ),
        ),
    ]);
  }

  Widget _clipsList() {
    return _panel([
      Text('المقاطع المحفوظة (${clips.length})',
          style: const TextStyle(fontWeight: FontWeight.bold)),
      for (var i = 0; i < clips.length; i++)
        ListTile(
          dense: true,
          contentPadding: EdgeInsets.zero,
          leading: const Icon(Icons.movie_outlined),
          title: Text('مقطع ${i + 1}'),
          subtitle: Text(
              '${_fmt(clips[i].start)} → ${_fmt(clips[i].end)}  (${_fmt(clips[i].length)})'),
          onTap: () {
            setState(() => range = RangeValues(clips[i].start, clips[i].end));
            _seek(clips[i].start);
          },
          trailing: IconButton(
            icon: const Icon(Icons.delete_outline),
            onPressed: () => setState(() => clips.removeAt(i)),
          ),
        ),
    ]);
  }
}
